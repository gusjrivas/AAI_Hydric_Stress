Capturas — Explorar una predicción (reproducción histórica guiada)
Rama: feat/replay-ui-guided-experience (PR #215)
Instancia usada: Docker local, frontend en http://localhost:5196, backend en http://localhost:8111,
apuntando al paquete autorizado replay_packages/base-seed4-1157696b7b-v2 del checkout main
(evita el problema de CRLF del checkout en Windows dentro del worktree).

01 - Landing de "Explorar una predicción" (nuevo destino de navegación de primera clase).
02 - Control temporal: "Datos disponibles hasta", fechas de datos/reloj/objetivo distinguidas.
03 - Gráfico integrado antes de revelar (umbral, origen, objetivo, intervalo oculto).
     Corregido un solapamiento real entre la etiqueta "Predicción archivada (clase, no humedad)"
     y la fecha del eje (AXIS_MARGIN_BOTTOM insuficiente en MoistureHistoryChart.tsx);
     ver commit de fix aplicado sobre la rama del PR.
04 - Estado inmediatamente después de "Ver qué ocurrió": reloj en la fecha objetivo,
     "Volver al inicio de este caso" habilitado.
05 - Observación revelada (punto verde) + comparación numérica (qué anticipó el modelo,
     humedad observada, umbral, relación con el umbral).
06 - Resultado completo: categoría "Omisión de alerta", distancia física al umbral con signo
     y unidad, aclaración de que no es un error numérico del modelo, y sección de feedback
     de demostración (aislado del entrenamiento).
07 - Cambio de caso: al elegir otro origen (2024-10-20) el reloj se reubica automáticamente
     y "Volver al inicio de este caso" vuelve a estar deshabilitado (caso nuevo, sin resultado
     previo visible).

Limitación pendiente: no fue posible verificar visualmente el layout de pantalla pequeña.
La herramienta de redimensionado de ventana del navegador no cambió el viewport efectivo
en este entorno (mismo hallazgo que reportó el agente que implementó el cambio). El CSS
usa grillas auto-fit/minmax y flex-wrap pensadas para colapsar a una columna, pero eso es
revisión de código, no una comprobación visual real.
